# app_final_final.py
# النسخة النهائية النهائية من المساعد الصوتي — ادعم Wake Word عربي/إنجليزي + جلسة مستمرة + corpus favorites_ar
# ملاحظات: هذه النسخة تحتوي كل التحسينات النهائية، يفضل حفظها كملف مستقل وتشغيله لو سمحت
import os
import glob
import random
import threading
import queue
import time
import subprocess
import sys
import tempfile
from dotenv import load_dotenv

import tkinter as tk
from tkinter import scrolledtext, ttk

import speech_recognition as sr
from gtts import gTTS

import pygame

# -------------------------
# Configuration / Constants (يمكن تعديلها بسهولة هنا)
# -------------------------
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")  # ضع مفتاحك إن وُجد
MODEL_NAME = "models/gemini-2.0-flash"  # Use 2.0-flash for stability
IDLE_TIMEOUT_SECONDS = 25.0   # ثواني قبل انتهاء الجلسة تلقائيًا
WAKE_WORDS = ("يا مساعد", "hey assistant")
# كلمات الإيقاف )
STOP_KEYWORDS = ("سلام","خلاص", "اقفل", "اقفِل", "انهي", "انهي الجلسة", "مع السلامة", "باي", "stop", "close", "goodbye")

# Gemini SDK
try:
    import google.generativeai as genai
    print("✅ Google generativeai imported successfully")
except Exception as e:
    print(f"❌ Gemini import failed: {e}")
    genai = None

# Configure Gemini client
if GEMINI_API_KEY and genai:
    try:
        genai.configure(api_key=GEMINI_API_KEY)
        print("✅ Gemini configured successfully")
    except Exception as e:
        print("⚠️ Gemini configure failed:", e)
else:
    print(f"❌ Gemini not configured - API Key: {GEMINI_API_KEY is not None}, genai: {genai is not None}")

# -------------------------
# Load simple corpus files
# -------------------------
def load_corpus(folder="corpus"):
    """
    Reads all expected corpus files. تأكد أن ملف favorites_ar.txt موجود داخل المجلد 'corpus'
    Each file is a plain UTF-8 text file with one response per line.
    """
    corpus = {
        "jokes_ar": [], "jokes_en": [],
        "facts_ar": [], "facts_en": [],
        "greetings_ar": [], "greetings_en": [],
        "favorites_ar": []   # <-- المفتاح الجديد )
    }
    if not os.path.exists(folder):
        print(f"⚠️ Folder '{folder}' not found. Creating it.")
        try:
            os.makedirs(folder, exist_ok=True)
        except:
            pass
        return corpus

    for file in glob.glob(os.path.join(folder, "*.txt")):
        name = os.path.basename(file).split(".")[0].lower()
        if name in corpus:
            try:
                with open(file, "r", encoding="utf-8") as f:
                    lines = [l.strip() for l in f.readlines() if l.strip()]
                    corpus[name] = lines
                    print(f"📚 Loaded {len(lines)} lines from {name}")
            except Exception as e:
                print(f"Error loading corpus file {file}:", e)
    return corpus

# Initial load
CORPUS = load_corpus()

# -------------------------
# Helpers
# -------------------------
def detect_language(text):
    return "ar" if any("\u0600" <= ch <= "\u06FF" for ch in text) else "en"

# -------------------------
# Audio playback queue + pygame worker (NO PLAYSOUND)
# -------------------------
audio_queue = queue.Queue()
pygame_initiated = False

def init_pygame():
    global pygame_initiated
    if not pygame_initiated:
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
            pygame_initiated = True
            print("✅ Pygame mixer initialized successfully")
        except Exception as e:
            print("❌ Pygame init error:", e)

def _playback_worker():
    init_pygame()
    while True:
        path = audio_queue.get()
        if path is None:
            break
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy():
                pygame.time.wait(100)  # Wait 100ms between checks
        except Exception as e:
            print("Playback error:", e)
        finally:
            try:
                if os.path.exists(path):
                    os.remove(path)
            except:
                pass

def speak_text(text, lang="ar"):
    """توليد ملف TTS مؤقت ووضعه في طابور التشغيل باستخدام pygame فقط"""
    if not text or not text.strip():
        return
    
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tf:
            tmp = tf.name
        
        tts = gTTS(text=text, lang=lang)
        tts.save(tmp)
        audio_queue.put(tmp)
        
    except Exception as e:
        print("TTS error:", e)
        try:
            if tmp and os.path.exists(tmp):
                os.remove(tmp)
        except:
            pass

# Start playback thread
playback_thread = threading.Thread(target=_playback_worker, daemon=True)
playback_thread.start()

# -------------------------
# Open website helper
# -------------------------
def open_website(url):
    try:
        if sys.platform.startswith("win"):
            os.startfile(url)
        elif sys.platform.startswith("darwin"):
            subprocess.run(["open", url])
        else:
            subprocess.run(["xdg-open", url])
    except Exception as e:
        print("open_website error:", e)

# -------------------------
# Gemini response extraction (flexible)
# -------------------------
def _search_text(obj):
    if isinstance(obj, str):
        return obj.strip()
    if isinstance(obj, dict):
        for v in obj.values():
            r = _search_text(v)
            if r:
                return r
    if isinstance(obj, (list, tuple)):
        parts = []
        for i in obj:
            r = _search_text(i)
            if r:
                parts.append(r)
        return "\n".join(parts)
    return ""

def extract_text_from_gen(resp):
    try:
        txt = getattr(resp, "text", None)
        if txt:
            return txt.strip()
        parts = getattr(resp, "parts", None) or getattr(resp, "output", None)
        if parts:
            r = _search_text(parts)
            if r:
                return r
        return str(resp)
    except Exception as e:
        print("extract error:", e)
        return ""

def chat_with_api(msg, lang="ar"):
    if not GEMINI_API_KEY or not genai:
        return "⚠️ Gemini API key not configured."
    
    try:
        model = genai.GenerativeModel(MODEL_NAME)
        response = model.generate_content(msg)
        return response.text
    except Exception as e:
        print(f"Gemini API error: {e}")
        return f"⚠️ API Error: {str(e)}"

# -------------------------
# Wake word detection (tries Arabic then English)
# -------------------------
def listen_for_wakeword(recognizer, microphone, wake_words=WAKE_WORDS):
    try:
        with microphone as source:
            recognizer.adjust_for_ambient_noise(source, duration=0.3)
            audio = recognizer.listen(source, phrase_time_limit=3)
        text = ""
        try:
            text = recognizer.recognize_google(audio, language="ar-EG")
        except Exception:
            try:
                text = recognizer.recognize_google(audio, language="en-US")
            except Exception:
                text = ""
        text = (text or "").lower()
        print("wake heard:", text)
        for w in wake_words:
            if w.lower() in text:
                return True
        return False
    except Exception as e:
        print("wakeword listen error:", e)
        return False

# -------------------------
# UI Languages
# -------------------------
LANGUAGES = {
    "Arabic 🇪🇬": ("ar-EG", "ar"),
    "English 🇬🇧": ("en-US", "en")
}

# -------------------------
# Main App
# -------------------------
class SpeechRecognitionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🎤 Voice Assistant (Final)")
        self.root.geometry("980x620")
        self.root.configure(bg="#F8F9FA")

        # recognizer & microphone
        self.recognizer = sr.Recognizer()
        self.microphone = None

        # states
        self.is_listening = False
        self.wake_mode_active = False
        self.wake_thread = None
        self.conversation_active = False

        # GUI queue
        self.gui_queue = queue.Queue()

        # language
        self.current_lang_name = tk.StringVar(value="Arabic 🇪🇬")
        self.recog_lang, self.interface_lang = LANGUAGES[self.current_lang_name.get()]

        # Build UI
        toolbar = tk.Frame(root, bg="#ECECEC", bd=1, relief="raised")
        toolbar.pack(padx=8, pady=8, fill=tk.X)

        self.start_btn = tk.Button(toolbar, text="🎧 Start Listening", command=self.start_listening, bg="#28a745", fg="white", width=16)
        self.start_btn.pack(side=tk.LEFT, padx=4)

        self.stop_btn = tk.Button(toolbar, text="🛑 Stop", command=self.stop_listening, bg="#dc3545", fg="white", width=10)
        self.stop_btn.pack(side=tk.LEFT, padx=4)

        tk.Button(toolbar, text="🧹 Clear Log", command=self.clear_log, bg="#ffc107", width=10).pack(side=tk.LEFT, padx=4)

        self.reload_btn = tk.Button(toolbar, text="🔁 Reload Corpus", command=self.reload_corpus, bg="#6c757d", fg="white", width=14)
        self.reload_btn.pack(side=tk.LEFT, padx=4)

        self.wake_btn = tk.Button(toolbar, text="🎙️ Wake Word Mode: OFF", command=self.toggle_wake_mode, bg="#007bff", fg="white", width=20)
        self.wake_btn.pack(side=tk.LEFT, padx=6)

        tk.Label(toolbar, text="🌐 Language:", bg="#ECECEC").pack(side=tk.LEFT, padx=(20,4))
        self.lang_box = ttk.Combobox(toolbar, textvariable=self.current_lang_name, values=list(LANGUAGES.keys()), width=20)
        self.lang_box.pack(side=tk.LEFT)
        self.lang_box.bind("<<ComboboxSelected>>", self.change_language)

        # Log area
        self.log = scrolledtext.ScrolledText(root, state="disabled", font=("Consolas", 11))
        self.log.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Status
        self.status = tk.Label(root, text="🟢 Ready.", bg="#EFEFEF", anchor="w")
        self.status.pack(fill=tk.X, padx=10, pady=(0,10))

        # Close protocol
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.after(200, self.process_queue)

    # -------------------------
    def init_mic(self):
        if self.microphone is None:
            try:
                self.microphone = sr.Microphone()
            except Exception as e:
                self.log_message("⚠️ Microphone init error: " + str(e))
                self.microphone = None

    # -------------------------
    def start_listening(self):
        self.init_mic()
        if not self.microphone:
            return
        if self.is_listening:
            return
        self.is_listening = True
        self.start_btn.config(state="disabled")
        self.status.config(text="🎧 Listening...")
        threading.Thread(target=self.listen_loop, daemon=True).start()

    def stop_listening(self):
        self.is_listening = False
        self.start_btn.config(state="normal")
        self.status.config(text="🛑 Stopped")

    # -------------------------
    def recognize_speech_once(self, timeout=6):
        try:
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=0.3)
                audio = self.recognizer.listen(source, phrase_time_limit=timeout)
            return self.recognizer.recognize_google(audio, language=self.recog_lang)
        except Exception as e:
            print("recognize_once error:", e)
            return ""

    def recognize_speech(self):
        try:
            with self.microphone as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=0.4)
                audio = self.recognizer.listen(source)
            return self.recognizer.recognize_google(audio, language=self.recog_lang)
        except Exception as e:
            print("Speech recognition error:", e)
            return ""

    # -------------------------
    def listen_loop(self):
        while self.is_listening:
            text = self.recognize_speech()
            if text:
                self.log_message(f"👤 You said: {text}")
                lang = detect_language(text)
                try:
                    response = self.handle_command(text, lang)
                except Exception as e:
                    print("handle_command error:", e)
                    response = "⚠️ Error processing your request."

                # If it's a session-close command, stop everything
                if isinstance(response, str) and response == "__SESSION_CLOSE__":
                    self.log_message("🔴 User requested stop. Stopping listening & wake mode.")
                    speak_text("مع السلامة" if lang == "ar" else "Goodbye", "ar" if lang == "ar" else "en")
                    self.stop_listening()
                    self.stop_wake_mode()
                    break

                if response and response.strip():
                    self.log_message(f"🤖 Assistant: {response}")
                    tts_lang = "ar" if lang == "ar" else "en"
                    speak_text(response, tts_lang)
            else:
                self.log_message("😶 لم يتم التعرف على كلام.")
            time.sleep(0.25)

    # -------------------------
    def handle_command(self, text, lang):
        text_low = text.lower()

        # ---------- 1) Keywords for favorites (catch many phrasings) ----------
        fav_keywords = [
            "مين احسن دكتور",
            "مين أحسن دكتور",
            "مين افضل دكتور",
            "مين أفضل دكتور",
            "مين احسن دكتوره",
            "مين أفضل دكتوره",
            "مين احسن دكتور موجود",
            "مين افضل دكتور موجود",
            "احسن دكتور في الجامعة",
            "افضل دكتور في الجامعة",
            "مين احسن حد بيدرس",
            "مين افضل حد بيدرس",
            "ترشحلي دكتور كويس",
            "مين احسن دكتور في الكلية",
            "مين افضل دكتور في الكلية",
            "مين احسن دكتورة",
            "مين افضل دكتورة"
        ]

        if any(kw in text_low for kw in fav_keywords):
            return random.choice(
                CORPUS.get(
                    "favorites_ar",
                    ["تُعْتَبَرُ الدُّكْتُورَةُ عَبِيرُ حَسَنٍ هِيَ أَفْضَلُ دُكْتُورَةٍ مَوْجُودَةٍ فِي جَامِعَةِ حَلْوَانَ حَالِيًّا ❤"]
                )
            )

        # ---------- 2) Website opening (Arabic + English variants) ----------
        if "افتح" in text_low or "open" in text_low:
            if any(x in text_low for x in ["فيسبوك", "فيس بوك", "فيس"]):
                open_website("https://facebook.com")
                return "تم فتح فيسبوك" if lang == "ar" else "Opened Facebook"
            if any(x in text_low for x in ["يوتيوب", "اليوتيوب", "youtube"]):
                open_website("https://www.youtube.com")
                return "تم فتح يوتيوب" if lang == "ar" else "Opened YouTube"
            if any(x in text_low for x in ["انستا", "انستجرام", "instagram"]):
                open_website("https://instagram.com")
                return "تم فتح إنستجرام" if lang == "ar" else "Opened Instagram"
            if any(x in text_low for x in ["واتس", "واتساب", "whatsapp"]):
                open_website("https://web.whatsapp.com")
                return "تم فتح واتساب ويب" if lang == "ar" else "Opened WhatsApp Web"
            if any(x in text_low for x in ["تويتر", "twitter"]):
                open_website("https://twitter.com")
                return "تم فتح تويتر" if lang == "ar" else "Opened Twitter"
            if any(x in text_low for x in ["تيك", "تيك توك", "tiktok"]):
                open_website("https://www.tiktok.com")
                return "تم فتح تيك توك" if lang == "ar" else "Opened TikTok"
            if any(x in text_low for x in ["كروم", "chrome"]):
                try:
                    if sys.platform.startswith("win"):
                        os.system("start chrome")
                    elif sys.platform.startswith("darwin"):
                        subprocess.run(["open", "-a", "Google Chrome"])
                    else:
                        subprocess.run(["xdg-open", "https://www.google.com"])
                except:
                    pass
                return "تم فتح جوجل كروم" if lang == "ar" else "Opened Chrome"

        # ---------- 3) Simple local commands ----------
        if "نكت" in text_low:
            return random.choice(CORPUS.get("jokes_ar", ["معليش ما عندي نكت الآن."]))
        if "joke" in text_low:
            return random.choice(CORPUS.get("jokes_en", ["Sorry, no jokes right now."]))
        if "معلومة" in text_low:
            return random.choice(CORPUS.get("facts_ar", ["معليش ما عندي معلومة الآن."]))
        if "fact" in text_low:
            return random.choice(CORPUS.get("facts_en", ["No fact available."]))
        if any(w in text_low for w in ["اهلا", "مرحبا", "أهلا", "هاي"]):
            return random.choice(CORPUS.get("greetings_ar", ["أهلاً! كيف أقدر أساعدك؟"]))
        if any(w in text_low for w in ["hello", "hi"]):
            return random.choice(CORPUS.get("greetings_en", ["Hello! How can I help?"]))

        # ---------- 4) Session stop keywords ----------
        for sk in STOP_KEYWORDS:
            if sk.lower() in text_low:
                return "__SESSION_CLOSE__"

        # ---------- 5) Default: use Gemini ----------
        return chat_with_api(text, lang)

    # -------------------------
    def clear_log(self):
        self.log.config(state="normal")
        self.log.delete("1.0", tk.END)
        self.log.config(state="disabled")

    def reload_corpus(self):
        global CORPUS
        CORPUS = load_corpus()
        self.log_message("🔁 Corpus reloaded.")

    def change_language(self, event=None):
        self.recog_lang, self.interface_lang = LANGUAGES[self.current_lang_name.get()]

    def log_message(self, text):
        self.gui_queue.put(text)

    def process_queue(self):
        try:
            while True:
                msg = self.gui_queue.get_nowait()
                self.log.config(state="normal")
                self.log.insert(tk.END, msg + "\n")
                self.log.see(tk.END)
                self.log.config(state="disabled")
        except:
            pass
        self.root.after(200, self.process_queue)

    # -------------------------
    # Wake Mode + Conversation Session
    def toggle_wake_mode(self):
        if not self.wake_mode_active:
            self.start_wake_mode()
        else:
            self.stop_wake_mode()

    def start_wake_mode(self):
        self.init_mic()
        if not self.microphone:
            return
        if self.wake_mode_active:
            return
        self.wake_mode_active = True
        self.wake_btn.config(text="🎙️ Wake Word Mode: ON", bg="#28a745")
        self.log_message("🔵 Waiting for Wake Word… Say 'يا مساعد' or 'hey assistant'")
        self.status.config(text="🎙️ Waiting for Wake Word…")
        self.wake_thread = threading.Thread(target=self.wake_loop, daemon=True)
        self.wake_thread.start()

    def stop_wake_mode(self):
        self.wake_mode_active = False
        self.conversation_active = False
        self.wake_btn.config(text="🎙️ Wake Word Mode: OFF", bg="#007bff")
        self.log_message("⚪ Wake Word Mode OFF")
        self.status.config(text="🟢 Ready.")
        self.start_btn.config(state="normal")

    def wake_loop(self):
        while self.wake_mode_active:
            detected = listen_for_wakeword(self.recognizer, self.microphone, wake_words=WAKE_WORDS)
            if detected:
                self.log_message("🟣 Wake Word detected — starting continuous session.")
                resp_prompt = "نعم؟" if self.interface_lang == "ar" else "Yes?"
                speak_text(resp_prompt, "ar" if self.interface_lang == "ar" else "en")

                # disable start button during session
                self.start_btn.config(state="disabled")

                self.conversation_active = True
                idle_start = time.time()

                while self.conversation_active and self.wake_mode_active:
                    cmd = self.recognize_speech_once(timeout=6)
                    if cmd:
                        idle_start = time.time()
                        self.log_message(f"👤 (in-session) You said: {cmd}")
                        lang = detect_language(cmd)
                        try:
                            resp = self.handle_command(cmd, lang)
                        except Exception as e:
                            print("handle_command(session) error:", e)
                            resp = "⚠️ Error processing your request."

                        if isinstance(resp, str) and resp == "__SESSION_CLOSE__":
                            bye_msg = "مع السلامة" if lang == "ar'else 'Goodbye" else "Goodbye"
                            # safe fallback if language detection weird (ensure string)
                            bye_msg = ("مع السلامة" if lang == "ar" else "Goodbye")
                            speak_text(bye_msg, "ar" if lang == "ar'else 'en" else "en")
                            self.log_message("🔴 Session closed by user command.")
                            # stop everything as requested
                            self.conversation_active = False
                            self.stop_listening()
                            self.stop_wake_mode()
                            break

                        if resp and resp.strip():
                            self.log_message(f"🤖 Assistant: {resp}")
                            tts_lang = "ar" if lang == "ar" else "en"
                            speak_text(resp, tts_lang)
                    else:
                        if (time.time() - idle_start) > IDLE_TIMEOUT_SECONDS:
                            self.log_message("⏳ Session ended automatically due to inactivity.")
                            speak_text("تم إيقاف الجلسة لعدم وجود نشاط." if self.interface_lang == "ar" else "Session ended due to inactivity.", "ar" if self.interface_lang == "ar" else "en")
                            self.conversation_active = False
                            break
                    time.sleep(0.2)

                # session ended -> re-enable start button (if not already stopped)
                if not self.is_listening:
                    self.start_btn.config(state="normal")
                if self.wake_mode_active:
                    self.log_message("🔵 Back to waiting for Wake Word...")
                    self.status.config(text="🎙️ Waiting for Wake Word…")
            time.sleep(0.2)

    # -------------------------
    def on_close(self):
        try:
            self.stop_listening()
            self.stop_wake_mode()
            audio_queue.put(None)
        except:
            pass
        self.root.destroy()

# -------------------------
# Run
# -------------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = SpeechRecognitionApp(root)
    root.mainloop()